﻿using System;


namespace StructureAndEnum
{
    enum Dept
    {
        Sales=456,HR=124,Accounts=234
    }

    enum Gender
    {
        Female=1,Male=2
    }
}
