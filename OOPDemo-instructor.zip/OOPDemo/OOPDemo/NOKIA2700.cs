﻿using System;


namespace OOPDemo
{
    class NOKIA2700:MobilePhone
    {
        public NOKIA2700()
        {
            Console.WriteLine("Default constructor of NOKIA2700");
        }
        public string MP4()
        {
            return "MP4() from NOKIA2700";
        }
    }
}
