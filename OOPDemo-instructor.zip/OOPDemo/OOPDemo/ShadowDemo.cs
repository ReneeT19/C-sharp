﻿using System;


namespace OOPDemo
{
    class ShadowDemo
    {
        static void Main()
        {
            MyMath1 m1 = new MyMath1();
            Console.WriteLine(m1.Add(45.2, 40));
            Console.ReadLine();
        }
    }
}
