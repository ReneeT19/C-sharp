﻿using System;


namespace OOPDemo
{
    class ConstructorDemo
    {
        static void Main()
        {
            Employee emp = new Employee(120);
        }
    }
}
