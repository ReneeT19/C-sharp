﻿using System;


namespace OOPDemo
{
    interface IWIFI
    {
        string StartWIFI();
        string ConnectWIFI();
        string StopWIFI();
    }
}
