﻿using System;


namespace OOPDemo
{
    class NOKIA1100:NOKIA1400
    {
        public NOKIA1100()
        {
            Console.WriteLine("Default constructor of NOKIA1100");
        }

        public string Camera()
        {
            return "Camera() from NOKIA1100";
        }
    }
}
