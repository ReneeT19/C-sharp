﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemoWithConsole2
{
    class EmpProfileBL
    {
        EMPCOGNIXIAEntities dbcontext = new EMPCOGNIXIAEntities();
        public bool SaveEmployee(EmpProfile emp)
        {
            if (emp != null)
            {
                dbcontext.EmpProfiles.Add(emp);
                dbcontext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteEmployee(int EmpCode)
        {
            if (EmpCode > 0)
            {
                var emp = dbcontext.EmpProfiles.Where(x => x.EmpCode == EmpCode).FirstOrDefault();
                if (emp != null)
                {
                    dbcontext.EmpProfiles.Remove(emp);
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        public bool UpdateEmployee(EmpProfile emp)
        {
            if (emp != null)
            {
                var existemp = dbcontext.EmpProfiles.Where(x => x.EmpCode == emp.EmpCode).FirstOrDefault();
                existemp.EmpName = emp.EmpName;
                existemp.DateOfBirth = emp.DateOfBirth;
                existemp.DeptCode = emp.DeptCode;
                dbcontext.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public EmpProfile GetEmployeeByEmpCode(int EmpCode)
        {
            var emp = dbcontext.EmpProfiles.Where(x => x.EmpCode == EmpCode).FirstOrDefault();
            return emp;
        }

        public List<EmpProfile> GetAllEmployees()
        {
            var emplist = dbcontext.EmpProfiles.ToList();
            return emplist;
        }

        public List<EmpProfile> GetEmployeesByDeptCode(int DeptCode)
        {
            var emplist = dbcontext.EmpProfiles.Where(x => x.DeptCode == DeptCode).ToList();
            return emplist;
        }
    }
}
