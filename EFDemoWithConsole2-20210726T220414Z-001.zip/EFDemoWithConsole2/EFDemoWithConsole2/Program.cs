﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDemoWithConsole2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter you Choice:1.Save 2.Delete 3.Update 4.Get Employee by Code 5.Get All Employees 6.Get Employees By Dept Code");
            int no = Convert.ToInt32(Console.ReadLine());
            EmpProfileBL empbo = new EmpProfileBL();
            switch (no)
            {
             case 1 : 
                   
                    EmpProfile emp = new EmpProfile { EmpCode = 106, EmpName = "Jhones", DateOfBirth = new DateTime(1978, 02, 03), DeptCode = 2 };
                    if (empbo.SaveEmployee(emp))
                    {
                        Console.WriteLine("Employee Information is Saved");
                    }
              break;
              case 2: 
                   if(empbo.DeleteEmployee(102))
                    {
                        Console.WriteLine("Employee Information is Deleted");
                    }
                    break;
                case 3:
                    EmpProfile empnew = new EmpProfile { EmpCode = 106, EmpName = "Mash", DateOfBirth = new DateTime(1975, 01, 01), DeptCode = 1 };
                   if(empbo.UpdateEmployee(empnew))
                    {
                        Console.WriteLine("Employee Information is Updated");
                    }
                    break;
                case 4:
                    var empobj = empbo.GetEmployeeByEmpCode(106);
                    Console.WriteLine($"Code={empobj.EmpCode} Name={empobj.EmpName} Date of Birth={empobj.DateOfBirth} Dept Code={empobj.DeptCode}");
                    break;
                case 5:
                    var emplist = empbo.GetAllEmployees();
                    foreach(var e in emplist)
                    {
                        Console.WriteLine($"Code={e.EmpCode} Name={e.EmpName} Date of Birth={e.DateOfBirth} Dept Code={e.DeptCode}");

                    }
                    break;
                case 6:
                    var emplist1 = empbo.GetEmployeesByDeptCode(2);
                      foreach(var e1 in emplist1)
                    {
                        Console.WriteLine($"Code={e1.EmpCode} Name={e1.EmpName} Date of Birth={e1.DateOfBirth} Dept Code={e1.DeptCode}");

                    }
                    break;
            }
           
         
            Console.ReadLine();
        }
    }
}
