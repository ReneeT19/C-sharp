﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EFDemoWithWinforms
{
    public partial class Form1 : Form
    {
        EmpProfileBL empprofilebl = new EmpProfileBL();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            EmpProfile emp = new EmpProfile ();
            emp.EmpCode =Convert.ToInt32( txtCode.Text);
            emp.EmpName = txtName.Text;
            emp.DateOfBirth = dtpDob.Value;
            emp.DeptCode =Convert.ToInt32( txtDeptCode.Text);
          if(empprofilebl.SaveEmployee(emp))
            {
                MessageBox.Show("Employee Information is Saved");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int EmpCode = Convert.ToInt32(txtCode.Text);
           if(empprofilebl.DeleteEmployee(EmpCode))
            {
                MessageBox.Show("Employee Information Deleted Successfully");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            EmpProfile emp = new EmpProfile();
            emp.EmpCode = Convert.ToInt32(txtCode.Text);
            emp.EmpName = txtName.Text;
            emp.DateOfBirth = dtpDob.Value;
            emp.DeptCode = Convert.ToInt32(txtDeptCode.Text);
          if(empprofilebl.UpdateEmployee(emp))
            {
                MessageBox.Show("Employee Information is Updated");
            }
        }

        private void btnGetById_Click(object sender, EventArgs e)
        {
            int Code = Convert.ToInt32(txtCode.Text);
            var emp = empprofilebl.GetEmployeeByEmpCode(Code);
            txtName.Text = emp.EmpName;
            dtpDob.Text = emp.DateOfBirth.ToString();
            txtDeptCode.Text = emp.DeptCode.ToString();
        }

        private void btnGetAll_Click(object sender, EventArgs e)
        {
            var emplist = empprofilebl.GetAllEmployees();
            dataGridView1.DataSource = emplist;
            dataGridView1.Columns[4].Visible = false;
        }

        private void btnGetAllbyDeptCode_Click(object sender, EventArgs e)
        {
            int deptcode =Convert.ToInt32( txtDeptCode.Text);
            var emplist = empprofilebl.GetEmployeesByDeptCode(deptcode);
            dataGridView1.DataSource = emplist;
            dataGridView1.Columns[4].Visible = false;
        }
    }
}
