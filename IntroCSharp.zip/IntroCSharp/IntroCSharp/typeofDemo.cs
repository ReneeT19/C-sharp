﻿using System;


namespace IntroCSharp
{
    class typeofDemo
    {
        static void Main()
        {
            Console.WriteLine("managed type of int is {0} and for long is {1} ",typeof(int),typeof(long));
            Console.WriteLine($"managed type of int is {typeof(int)} and for long is {typeof(long)}");
            Console.WriteLine($"The sum of 11 and 22 is {11}");
            Console.ReadLine();
        }
    }
}
