﻿using System;


namespace IntroCSharp
{
  /// <summary>
  /// This is basic class
  /// </summary>
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //this contains number
            int num1 = 30;
            //this contains series of characters
            string str = "abc";
            /*
             * 
             * multi line comment
             */
        }
        /// <summary>
        /// This function prints a message.
        /// </summary>
        /// <param name="msg">This accept text</param>
        public  void Message(string msg)
        {
            Console.WriteLine(msg);
        }
    }
}
