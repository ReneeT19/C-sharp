﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroCSharp
{
    class Class1
    {
        static void Main(string[] args)
        {
          
            Program p = new Program();
            p.Message("Hello World");
            Console.ReadLine();
        }
    }
}
