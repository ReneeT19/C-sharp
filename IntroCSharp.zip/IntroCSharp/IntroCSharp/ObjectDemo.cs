﻿using System;


namespace IntroCSharp
{
    class ObjectDemo
    {
        static void Main()
        {
            int num = 4;
            Object myobj = 34;
            Object myobj1 = "welcome";
            Object myobj2 = 'A';
            Object myobj3 = true;
            Console.WriteLine($"{myobj} {myobj1} {myobj2} {myobj3}");
            Console.ReadLine();
        }
    }
}
