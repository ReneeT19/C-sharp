﻿using System;

namespace ArraysAndCollections
{
    class Employee
    {
        public int EmpCode { get; set; }
        public string EmpName { get; set; }
        public string Email { get; set; }

    }
}
